#!/usr/bin/env python3
#
import sys

def calculator(key, value):
    param = value * (1-0.165)
    untax = param - 3500
    if untax < 0:
        tax = 0.00
    elif untax < 1500:
        tax = untax * 0.03
    elif untax < 4500:
        tax = untax * 0.10 - 105
    elif untax < 9000:
        tax = untax * 0.20 - 555
    elif untax < 35000:
        tax = untax * 0.25 - 1005
    elif untax < 55000:
        tax = untax * 0.30 - 2755
    elif untax < 80000:
        tax = untax * 0.35 - 5505
    else:
        tax = untax * 0.45 - 13505
    print("%d:%.2f" % (key,param-tax))
   



import sys
if __name__ == "__main__":
    try:
        param = dict()
        if len(sys.argv) >= 2:
            for arg in sys.argv[1:]:
                arg = arg.split(':')
                param[int(arg[0])] = int(arg[1])
        else:
            raise TypeError("")
        for key, value in param.items():
            calculator(key, value)
    except:
        print("Parameter Error")
