#!/usr/bin/env python3
#

import sys
import csv

class Args():
    def __init__(self):
        args = sys.argv[1:]
        try:
            self.configfile = args[args.index('-c') + 1]
            self.userdatafile = args[args.index('-d') + 1]
            self.exportfile = args[args.index('-o') + 1]
        except:
            print("Paramater Error")

class Config():
    def __init__(self,configfile):
        self._configfile = configfile
        self._config = self._read_config()
        
    def _read_config(self):
        configdict = {}
        with open(self._configfile) as configs:
            for config in  configs:
                config = config.split('=')
                key = ''.join(config[0].split())
                value = ''.join(config[1].split())
                configdict[key] = float(value)
        return configdict

    def get_config(self):
        return self._config

class UserData():
    def __init__(self, userdatafile):
        self._userdatafile = userdatafile
        self._userdata = self._read_users_data()

    def _read_users_data(self):
        userdatalist = []
        with open(self._userdatafile) as userdatas:
            userdatas = csv.reader(userdatas)
            for userdata in userdatas:
                userdatatu = (float(userdata[0]),float(userdata[1]))
                userdatalist.append(userdatatu)
        return userdatalist

    def get_userdata(self):
        return self._userdata

class IncomeTaxCalcultator(object):
    def __init__(self,config, userdata, exportfile):
        self._config = config
        self._userdata = userdata
        self._exportfile = exportfile

    def calc_for_all_userdata(self):
        all_userdata = list()
        taxconfig = self._config['YangLao'] + self._config['YiLiao'] + self._config['ShiYe'] + self._config['GongShang'] + self._config['ShengYu'] + self._config['GongJiJin']
        for uds in self._userdata:
            user = uds[0]
            income = uds[1]
            if income > self._config['JiShuH']:
                self._income = self._config['JiShuH']
            elif income < self._config['JiShuL']:
                self._income = self._config['JiShuL']
            else:
                self._income = income
            self._calc_tax(income,taxconfig)
            user_data = [int(user), "%.2f"%self.after_tax_income, "%.2f"%self._tax, "%.2f"%self._shebao]
            all_userdata.append(user_data)
        return all_userdata

    def _calc_tax(self, income, pertax):
        param = self._income * pertax
        untax = income - param - 3500
        if untax < 0:
           tax = 0.00
        elif untax < 1500:
           tax = untax * 0.03
        elif untax < 4500:
           tax = untax * 0.10 - 105
        elif untax < 9000:
           tax = untax * 0.20 - 555
        elif untax < 35000: 
           tax = untax * 0.25 - 1005
        elif untax < 55000: 
           tax = untax * 0.30 - 2755
        elif untax < 80000: 
           tax = untax * 0.40 - 5505
        else:
           tax = untax * 0.45 - 13505
        self._income = income
        self._shebao = param
        self._tax = tax
        self.after_tax_income = income - param - tax
        

    def export(self, default='csv'):
        result = self.calc_for_all_userdata()
        with open(self._exportfile, 'w') as f:
            writer = csv.writer(f)
            writer.writerows(result)

if __name__ == '__main__':
    args = Args()
    config = Config(args.configfile)
    userdata = UserData(args.userdatafile)
    incometax = IncomeTaxCalcultator(config.get_config(), userdata.get_userdata(), args.exportfile)
    incometax.export()
    
