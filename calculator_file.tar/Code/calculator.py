#!/usr/bin/env python3
#

import sys
import csv

class Config():
    def __init__(self,configfile):
        self._config = self._read_config()

    def _read_config(self):
        configdict = {}
        with open(configfile) as configs:
            for config in  configs:
                config = config.strip().split('=') 
                configdict[config[0]] = config[1]
        return configdict

    def get_config(self,config):
        return self._config[config]

class UserData():
    def __init__(self, userdatafile):
        self._userdata = self._read_users_data()

    def _read_users_data(self):
        userdatalist = []
        with open(userdatafile) as userdatas:
            userdatas = csv.reader(userdatas)
            for userdata in userdatas:
                userdatatu = (userdata[0],userdata[1])
                userdatalist.append(userdatatu)
        return userdatalist

    def get_userdata(self):
        return self._userdata

class IncomeTaxCalcultator(object):
    def __init__(self):
        pass
   
    def calc_for_all_userdata(self):
        all_userdata = list()
        config = Config(self.configfile)
        userdata = UserData(self.userdatafile)
        taxconfig = config['YangLao'] + config['YiLiao'] + config['ShiYe'] + config['GongShang'] + config['ShengYu'] + config['GongJiJin']
        for uds in userdata.get_userdata():
            user = uds[0]
            income = uds[1]
            if income > config['JiShuH']:
                self._income = config['JiShuH']
            elif income < config['JiShuL']:
                self._income = config['JiShuL']
            else:
                self._income = income
            calc_tax(income,taxconfig)
            user_data = [user, '{}'.format(self_income, '.2f'), '{}'.format(self._tax, '.2f'), '{}'.format(self._shebao, '.2f')]
            all_userdata.append(user_data)
        return all_userdata

    def calc_tax(self, income, pertax):
        param = self._income * pertax
        untax = income - param - 3500
        if untax < 0:
           tax = 0.00
        elif untax < 1500:
           tax = untax * 0.03
        elif untax < 4500:
           tax = untax * 0.10 - 105
        elif untax < 9000:
           tax = untax * 0.20 - 555
        elif untax < 35000: 
           tax = untax * 0.25 - 1005
        elif untax < 55000: 
           tax = untax * 0.30 - 2755
        elif untax < 80000: 
           tax = untax * 0.40 - 5505
        else:
           tax = untax * 0.45 - 13505
        self._income = income
        self._shebao = param
        self._tax = tax
        self.after_tax_income = income - param - tax

        
    def get_data(self):
        indexs = (1, 3, 5)
        for index in indexs:
            if sys.argv[index] == '-c':
                self.configfile = sys.argv[index+1]
            elif sys.argv[index] == '-d':
                self.userdatafile = sys.argv[index+1]
            elif sys.argv[index] == '-o':
                self.exportfile = sys.argv[index+1]
            else:
                pass

    def export(self, default='csv'):
        rusult = self.calc_for_all_userdata()
        args = sys.argv[1:]
        filename = args[args.index('-o')+1]
        with open(filename) as f:
            writer = csv.writer(f)
            writer.writerows(result)
