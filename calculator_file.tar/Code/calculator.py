#!/usr/bin/env python3
#

import sys
import csv

class Config():
    def __init__(self,configfile)
        self._config = self._read_config()

    def _read_config(self)
        configdict = {}
        with open(configfile) as configs:
            for config in  configs:
                config = config.strip().split('=') 
                configdict[config[0]] = config[1]
        return configdict

    def get_config(self,config):
        return self._config[config]

class UserData():
    def __init__(self, userdatafile):
        self._userdata = self._read_users_data()

    def _read_users_data(self):
        userdatalist = []
        with open(userdatafile) as userdatas:
            userdatas = csv.reader(userdatas)
            for userdata in userdatas:
                userdatatu = (userdata[0],userdata[1])
                userdatalist.append(userdatatu)
        return userdatalist

    def get_userdata(self):
        return self._userdata

class IncomeTaxCalcultator(object):
    def __init__(self):
        pass
   
    def calc_for_all_userdata(self):
        config = Config(self.configfile)
        userdata = UserData(self.userdatafile)
        for uds in userdata.get_userdata()
            user = uds[0]
            income = uds[1]

        
    def get_data(self):
        indexs = (1, 3, 5)
        for index in indexs:
            if sys.argv[index] == '-c':
                self.configfile = sys.argv[index+1]
            elif sys.argv[index] == '-d':
                self.userdatafile = sys.argv[index+1]
            elif sys.argv[index] == '-o'
                self.exportfile = sys.argv[index+1]
            else
                pass

